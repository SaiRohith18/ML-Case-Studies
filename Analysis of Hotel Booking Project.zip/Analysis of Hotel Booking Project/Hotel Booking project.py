#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings 
warnings.filterwarnings('ignore')


# ### Loading dataset

# In[2]:


df = pd.read_csv('hotel_bookings 2.csv')
df


# ## EDA

# In[3]:


df.head()


# In[4]:


df.tail()


# In[5]:


df.shape


# In[6]:


df.columns


# In[7]:


df.info()


# In[8]:


df.describe()


# In[9]:


# reservation_status_date = convert to datetime


# In[10]:


df['reservation_status_date'] = pd.to_datetime(df['reservation_status_date'])


# In[11]:


df.describe(include = 'object')


# In[12]:


for col in df.describe(include = 'object').columns:
    print(col)
    print(df[col].unique())
    print('_'*50)


# In[13]:


df.isna().sum()


# In[14]:


df.drop(['company','agent'], axis = 1, inplace = True)
df.dropna(inplace = True)


# In[15]:


df.isna().sum()


# In[16]:


df.describe()


# In[17]:


# adr = average daily rate 
# we can see outlier there -6 -> 5400


# In[18]:


df['adr'].plot(kind = 'box')


# In[20]:


df = df[df['adr']<5000]
df


# ### Data Analysis and Visualizations

# In[21]:


cancelled_percentage = df['is_canceled'].value_counts(normalize = True)
cancelled_percentage


# In[22]:


# 62.8 percentage of the reservations are not cancelled 
# 37 percantentage of the reservations got cancelled


# In[24]:


plt.figure(figsize=(5,4))
plt.title("Reservation status count")
plt.bar(['Not cancelled' , 'cancelled'], df['is_canceled'].value_counts(),edgecolor='b',width = 0.7)


# In[77]:


plt.figure(figsize=(8,4))
axl = sns.countplot(x='hotel',hue='is_canceled',data = df,palette='Blues')
axl.legend(bbox_to_anchor=(1,1))
plt.title("Reservation status in different hotels",size=20)
plt.xlabel('hotel')
plt.ylabel('no.of reservations')
plt.legend(['not canceled','canceled'])
plt.show()


# This bar graph shows the percentage of reservations that are canceled and those that are not. It is obvious that there are still a significant number of reservations that have not been canceled. There are still 37% of clients who canceled their reservation, which has a significant impact on the hotel's earnings.

# In[30]:


resort_hotel = df[df['hotel'] == 'Resort Hotel']
resort_hotel['is_canceled'].value_counts(normalize = True)


# In[38]:


city_hotel = df[df['hotel'] == 'City Hotel']
city_hotel['is_canceled'].value_counts(normalize = True)


# In[42]:


resort_hotel = resort_hotel.groupby('reservation_status_date')[['adr']].mean()
city_hotel = city_hotel.groupby('reservation_status_date')[['adr']].mean()


# In[43]:


resort_hotel


# In[44]:


city_hotel


# In[45]:


plt.figure(figsize=(20,8))
plt.title('Average daily rate in city and resort hotel', fontsize = 30)
plt.plot(resort_hotel.index,resort_hotel['adr'],label = 'Resort Hotel')
plt.plot(city_hotel.index,city_hotel['adr'],label = 'City Hotel')
plt.legend(fontsize=20)
plt.show()


# In comparision to resort hotels, city hotels have more bookings.
# 
# its possible that resort hotels are more expensive than those in cities.

# In[46]:


# blue line - resort hotel
# orange line - city hotel


# In[53]:


df['month'] = df['reservation_status_date'].dt.month 
plt.figure(figsize=(16,8))
axl = sns.countplot(x='month',hue='is_canceled',data=df,palette='bright')
legend_labels,_ = axl.get_legend_handles_labels()
axl.legend(bbox_to_anchor=(1,1))
plt.title('reservation status per month',size=20)
plt.xlabel('month')
plt.ylabel('no.of reservations')
plt.legend(['not canceled','canceled'])
plt.show()


# In[54]:


# blue bar graph showing not canceled reservation
# orange bar graph showing canceled reservation


# In[55]:


# Highest cancellation is in january
# Lowest cancellation is in August


# The line graph above shows that, on certain days, the average daily rate for a city hotel is less than that of a resort hotel, and on other days, it is even less. It goes without saying that weekends and holidays may see a rise in resort rates.

# In[67]:


plt.figure(figsize=(15,8))
plt.title('ADR per month',fontsize = 30)
sns.barplot(x='month', y='adr', data=df[df['is_canceled'] == 1].groupby('month')[['adr']].sum().reset_index())
plt.show()


# In[68]:


# when the prices are high then the cancellations are getting high 


# We have developed the grouped bar graph to analyze the months with the highest and lowest reservation levels according to reservaiton status. As can be seen, both the number of confirmed reservations and the number of canceled reservations are largest in the month of August. whereas january is the month with the most canceled reservations.

# In[70]:


cancelled_data = df[df['is_canceled'] == 1]
top_10_country = cancelled_data['country'].value_counts()[:10]
plt.figure(figsize=(8,8))
plt.title('Top 10 countries with reservation canceled')
plt.pie(top_10_country,autopct='%.2f',labels=top_10_country.index)
plt.show()


# This bar graph demonstrates that cancellations are most common when prices are greatest and are least common when they are lowest. Therefore, the cost of the accomodation is soley responsible for the cancellation.
# 
# Now, lets see which country has the highest reservation cancelled.
# The top country is portugal with the highest number of cancellations.

# let's check the area from where guests are visiting the hotels and making resevations. 
# Is it coming from Direct or groups, Online or offline travel agents? 
# Around 46% of the clients come from online travel agencies, whereas 27% come from groups.
# Only 4% of clients book hotels directly by visiting them and making reservations.

# In[71]:


df['market_segment'].value_counts()


# In[72]:


df['market_segment'].value_counts(normalize = True)


# In[73]:


cancelled_data['market_segment'].value_counts(normalize = True)


# In[76]:


cancelled_df_adr = cancelled_data.groupby('reservation_status_date')[['adr']].mean()
cancelled_df_adr.reset_index(inplace = True)
cancelled_df_adr.sort_values('reservation_status_date',inplace = True)

not_cancelled_data = df[df['is_canceled'] == 0]
not_cancelled_df_adr = not_cancelled_data.groupby('reservation_status_date')[['adr']].mean()
not_cancelled_df_adr.reset_index(inplace=True)
not_cancelled_df_adr.sort_values('reservation_status_date',inplace=True)

plt.figure(figsize=(20,6))
plt.title('Average Daily Rate',fontsize = 30)
plt.plot(not_cancelled_df_adr['reservation_status_date'],not_cancelled_df_adr['adr'],label='not cancelled')
plt.plot(cancelled_df_adr['reservation_status_date'],cancelled_df_adr['adr'],label='cancelled')
plt.legend(fontsize=20)
plt.show()


# As seen in the graph, reservations are canceled when the average daily rate is higher than when it is not canceled. It clearly proves all the above analysis, that the higher price leads to higher cancellation.

# In[ ]:




